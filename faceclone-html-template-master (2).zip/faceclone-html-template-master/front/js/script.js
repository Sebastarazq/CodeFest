<script>
document.getElementById("registroButton").addEventListener("click", function() {
    // Redirige a la vista de inicio de sesión (login.html) al hacer clic en el botón "Registro".
    window.location.href = "../front/register.html";
});
</script>
